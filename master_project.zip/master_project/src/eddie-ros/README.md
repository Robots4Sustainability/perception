# Eddie Ros

A ROS 2 package for control and communication with Eddie, the robot.