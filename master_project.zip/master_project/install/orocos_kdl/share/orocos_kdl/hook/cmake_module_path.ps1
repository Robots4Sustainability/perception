# generated from colcon_powershell/shell/template/hook_prepend_value.ps1.em

colcon_prepend_unique_value CMAKE_MODULE_PATH "$env:COLCON_CURRENT_PREFIX\share/orocos_kdl/cmake"
