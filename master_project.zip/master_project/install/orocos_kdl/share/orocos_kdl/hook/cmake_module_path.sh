# generated from colcon_core/shell/template/hook_prepend_value.sh.em

_colcon_prepend_unique_value CMAKE_MODULE_PATH "$COLCON_CURRENT_PREFIX/share/orocos_kdl/cmake"
